## Naming conventions

### Component File and Components:

- Follow PascalCase for component files and components.

```javascript
ComponentName.jsx

class ComponentName

export default ComponentName
```
